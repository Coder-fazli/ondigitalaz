/***************************************************
 * OnDigital Theme - Global JS
 * Combined from: error-handling.js + main.js + offcanvas.js + backToTop.js
 ****************************************************/

// =====================================================
// ERROR HANDLING (error-handling.js)
// =====================================================
var device_width = window.screen.width;

// Text Move Animation (GSAP + SplitText)
let text_animation = gsap.utils.toArray(".has_text_move_anim");

if (text_animation) {
    text_animation.forEach(splitTextLine => {
        var delay_value = 0.1;
        if (splitTextLine.getAttribute("data-delay")) {
            delay_value = splitTextLine.getAttribute("data-delay");
        }
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger: splitTextLine,
                start: 'top 85%',
                duration: 1,
                scrub: false,
                markers: false,
                toggleActions: 'play none none none'
            }
        });

        const itemSplitted = new SplitText(splitTextLine, { type: "lines" });
        gsap.set(splitTextLine, { perspective: 400 });
        itemSplitted.split({ type: "lines" });
        tl.from(itemSplitted.lines, {
            duration: 1,
            delay: delay_value,
            opacity: 0,
            rotationX: -80,
            force3D: true,
            transformOrigin: "top center -50",
            stagger: 0.1
        });
    });
}

// Character Animation
var animation_char_come_items = document.querySelectorAll(".has_char_anim");
animation_char_come_items.forEach((item) => {
    var stagger_value = 0.05;
    var translateX_value = 20;
    var translateY_value = false;
    var onscroll_value = 1;
    var data_delay = 0.1;
    var data_duration = 1;
    var ease_value = "power2.out";

    if (item.getAttribute("data-stagger")) stagger_value = item.getAttribute("data-stagger");
    if (item.getAttribute("data-translateX")) translateX_value = item.getAttribute("data-translateX");
    if (item.getAttribute("data-translateY")) translateY_value = item.getAttribute("data-translateY");
    if (item.getAttribute("data-on-scroll")) onscroll_value = item.getAttribute("data-on-scroll");
    if (item.getAttribute("data-delay")) data_delay = item.getAttribute("data-delay");
    if (item.getAttribute("data-ease")) ease_value = item.getAttribute("data-ease");
    if (item.getAttribute("data-duration")) data_duration = item.getAttribute("data-duration");

    let charAnimSettings = { duration: data_duration, delay: data_delay, autoAlpha: 0, stagger: stagger_value, ease: ease_value };

    if (onscroll_value == 1) {
        charAnimSettings['scrollTrigger'] = { trigger: item, start: 'top 85%' };
    }

    let split_char = new SplitText(item, { type: "chars, words" });

    if (translateX_value && !translateY_value) {
        charAnimSettings['x'] = translateX_value;
    } else if (translateY_value && !translateX_value) {
        charAnimSettings['y'] = translateY_value;
    } else if (translateX_value && translateY_value) {
        charAnimSettings['x'] = translateX_value;
        charAnimSettings['y'] = translateY_value;
    } else {
        charAnimSettings['x'] = 50;
    }

    gsap.from(split_char.chars, charAnimSettings);
});

// Word Animation
let animation_word_anim_items = document.querySelectorAll(".has_word_anim");
animation_word_anim_items.forEach((word_anim_item) => {
    var stagger_value = 0.04;
    var translateX_value = false;
    var translateY_value = false;
    var onscroll_value = 1;
    var data_delay = 0.1;
    var data_duration = 0.75;

    if (word_anim_item.getAttribute("data-stagger")) stagger_value = word_anim_item.getAttribute("data-stagger");
    if (word_anim_item.getAttribute("data-translateX")) translateX_value = word_anim_item.getAttribute("data-translateX");
    if (word_anim_item.getAttribute("data-translateY")) translateY_value = word_anim_item.getAttribute("data-translateY");
    if (word_anim_item.getAttribute("data-on-scroll")) onscroll_value = word_anim_item.getAttribute("data-on-scroll");
    if (word_anim_item.getAttribute("data-delay")) data_delay = word_anim_item.getAttribute("data-delay");
    if (word_anim_item.getAttribute("data-duration")) data_duration = word_anim_item.getAttribute("data-duration");

    let wordAnimSettings = { duration: data_duration, delay: data_delay, autoAlpha: 0, stagger: stagger_value };

    if (onscroll_value == 1) {
        wordAnimSettings['scrollTrigger'] = { trigger: word_anim_item, start: 'top 85%' };
    }

    let split_word = new SplitText(word_anim_item, { type: "chars, words" });

    if (translateX_value && !translateY_value) {
        wordAnimSettings['x'] = translateX_value;
    } else if (translateY_value && !translateX_value) {
        wordAnimSettings['y'] = translateY_value;
    } else if (translateX_value && translateY_value) {
        wordAnimSettings['x'] = translateX_value;
        wordAnimSettings['y'] = translateY_value;
    } else {
        wordAnimSettings['x'] = 20;
    }

    gsap.from(split_word.words, wordAnimSettings);
});

// Fade Animation
let fadeArray_items = document.querySelectorAll(".has_fade_anim");
if (fadeArray_items.length > 0) {
    const fadeArray = gsap.utils.toArray(".has_fade_anim");
    fadeArray.forEach((item, i) => {
        var fade_direction = "bottom";
        var onscroll_value = 1;
        var duration_value = 1.15;
        var fade_offset = 50;
        var delay_value = 0.15;
        var ease_value = "power2.out";

        if (item.getAttribute("data-fade-offset")) fade_offset = item.getAttribute("data-fade-offset");
        if (item.getAttribute("data-duration")) duration_value = item.getAttribute("data-duration");
        if (item.getAttribute("data-fade-from")) fade_direction = item.getAttribute("data-fade-from");
        if (item.getAttribute("data-on-scroll")) onscroll_value = item.getAttribute("data-on-scroll");
        if (item.getAttribute("data-delay")) delay_value = item.getAttribute("data-delay");
        if (item.getAttribute("data-ease")) ease_value = item.getAttribute("data-ease");

        let animation_settings = {
            opacity: 0,
            ease: ease_value,
            duration: duration_value,
            delay: delay_value,
        };

        if (fade_direction == "top") animation_settings['y'] = -fade_offset;
        if (fade_direction == "left") animation_settings['x'] = -fade_offset;
        if (fade_direction == "bottom") animation_settings['y'] = fade_offset;
        if (fade_direction == "right") animation_settings['x'] = fade_offset;

        if (onscroll_value == 1) {
            animation_settings['scrollTrigger'] = { trigger: item, start: 'top 85%' };
        }
        gsap.from(item, animation_settings);
    });
}

// Pin sections
let mm = gsap.matchMedia();
mm.add("(min-width: 1024px)", () => {
    var pin_list = document.querySelectorAll(".section-item");
    pin_list.forEach((item) => {
        gsap.to(item, {
            scrollTrigger: {
                trigger: item,
                markers: false,
                pin: true,
                pinSpacing: false,
                start: "bottom bottom",
                end: "bottom -=500"
            },
        });
    });
});


// =====================================================
// MAIN JS (main.js)
// =====================================================
(function ($) {
    "use strict";

    // Sticky Header
    let header = document.querySelector('header');
    if (header) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 500) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }
        });
    }

    var overlay = document.querySelector('.overlay-switcher-close');

    // Preloader
    $(document).ready(function () {
        $('#container').addClass('loaded');
        if ($('#container').hasClass('loaded')) {
            $('#preloader').delay(1000).queue(function () {
                $(this).remove();
            });
        }
    });

    // Register GSAP Plugins
    gsap.registerPlugin(ScrollTrigger);

    // Magnific Image popup
    if ($('.image-popup').length && 'magnificPopup' in jQuery) {
        $('.image-popup').magnificPopup({
            type: "image",
            gallery: { enabled: true },
        });
    }

    // Magnific Video popup
    if ($('.video-popup').length && 'magnificPopup' in jQuery) {
        $('.video-popup').magnificPopup({ type: 'iframe' });
    }

    // Smooth scroll
    if (device_width > 767) {
        var smoothEl = document.querySelector("#has_smooth");
        if (smoothEl && smoothEl.classList.contains("has-smooth")) {
            ScrollSmoother.create({
                smooth: 0.5,
                effects: device_width < 1025 ? false : true,
                smoothTouch: 0.5,
                normalizeScroll: true,
                ignoreMobileResize: true,
            });
        }
    }

    // Counter active
    if ('counterUp' in window) {
        const skill_counter = window.counterUp.default;
        const skill_cb = entries => {
            entries.forEach(entry => {
                const el = entry.target;
                if (entry.isIntersecting && !el.classList.contains('is-visible')) {
                    skill_counter(el, { duration: 1500, delay: 16 });
                    el.classList.add('is-visible');
                }
            });
        };
        const IO = new IntersectionObserver(skill_cb, { threshold: 1 });
        const els = document.querySelectorAll('.wc-counter');
        els.forEach((el) => { IO.observe(el); });
    }

    // Scroll Top (ID based)
    let scroll_top = document.getElementById("scroll_top");
    if (scroll_top) {
        window.onscroll = function () {
            if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
                scroll_top.classList.add('showed');
            } else {
                scroll_top.classList.remove('showed');
            }
        };
        scroll_top.addEventListener('click', function () {
            document.body.scrollTop = 0;
            document.documentElement.scrollTop = 0;
        });
    }

    // Meanmenu
    if ($.fn.meanmenu) {
        $('.offcanvas__menu').meanmenu({
            meanScreenWidth: "5000",
            meanMenuContainer: '.offcanvas__menu-wrapper',
            meanMenuCloseSize: '28px',
        });

        $('.main-menu').meanmenu({
            meanScreenWidth: "1199",
            meanMenuContainer: '.offcanvas__menu-wrapper',
            meanMenuCloseSize: '28px',
        });
    }

    // Button move parallax
    const all_btn = gsap.utils.toArray(".btn-move");
    const all_btn_cirlce = gsap.utils.toArray(".btn-item");

    all_btn.forEach((btn, i) => {
        $(btn).mousemove(function (e) {
            parallaxIt(e, all_btn_cirlce[i], 80);
        });
        function parallaxIt(e, target, movement) {
            var $this = $(btn);
            var relX = e.pageX - $this.offset().left;
            var relY = e.pageY - $this.offset().top;
            gsap.to(target, 0.3, {
                x: ((relX - $this.width() / 2) / $this.width()) * movement,
                y: ((relY - $this.height() / 2) / $this.height()) * movement,
                scale: 1.2,
                ease: Power2.easeOut,
            });
        }
        $(btn).mouseleave(function (e) {
            gsap.to(all_btn_cirlce[i], 0.3, { x: 0, y: 0, scale: 1, ease: Power2.easeOut });
        });
    });

    // Button Hover Animation
    var btn_hover_all = document.querySelectorAll(".btn-hover-bgchange");
    if (btn_hover_all) {
        for (const ele of btn_hover_all) {
            var newSpan = document.createElement("span");
            ele.appendChild(newSpan);
        }
        $('.btn-hover-bgchange').on('mouseenter', function (e) {
            var x = e.pageX - $(this).offset().left;
            var y = e.pageY - $(this).offset().top;
            $(this).find('span').css({ top: y, left: x });
        });
        $('.btn-hover-bgchange').on('mouseout', function (e) {
            var x = e.pageX - $(this).offset().left;
            var y = e.pageY - $(this).offset().top;
            $(this).find('span').css({ top: y, left: x });
        });
    }

    // Pin Active
    var pin_fixed = document.querySelector('.pin__element');
    if (pin_fixed && device_width > 991) {
        gsap.to(".pin__element", {
            scrollTrigger: {
                trigger: ".pin__area",
                pin: ".pin__element",
                start: "top top",
                end: "bottom bottom",
                pinSpacing: false,
            }
        });
    }

    var schedule_fixed = document.querySelector('.pin__elem');
    if (schedule_fixed && device_width > 991) {
        gsap.utils.toArray(".pin__elem").forEach((panel, i, array) => {
            if (i === array.length - 1) return;
            ScrollTrigger.create({
                trigger: panel,
                start: "top top",
                pin: true,
                pinSpacing: false
            });
        });
    }

    // Cursor Movement
    function mousemoveHandler(e) {
        try {
            let tl = gsap.timeline({
                defaults: { x: e.clientX, y: e.clientY }
            });
            tl.to(".cursor1", { ease: "power2.out" })
              .to(".cursor2", { ease: "power2.out" }, "-=0.4");
        } catch (error) {
            console.log(error);
        }
    }
    document.addEventListener("mousemove", mousemoveHandler);

    // Image Reveal Animation
    let img_anim_reveal = document.querySelectorAll(".img_anim_reveal");
    img_anim_reveal.forEach((img_reveal) => {
        let image = img_reveal.querySelector("img");
        let tl = gsap.timeline({
            scrollTrigger: { trigger: img_reveal, start: "top 50%" }
        });
        tl.set(img_reveal, { autoAlpha: 1 });
        tl.from(img_reveal, 1.5, { xPercent: -100, ease: Power2.out });
        tl.from(image, 1.5, { xPercent: 100, scale: 1.3, delay: -1.5, ease: Power2.out });
    });

    // Offcanvas Menu Off/On
    var open_offcanvas = document.getElementById("open_offcanvas");
    var close_offcanvas = document.getElementById("close_offcanvas");
    if (open_offcanvas && close_offcanvas) {
        open_offcanvas.addEventListener('click', function () {
            document.querySelector('.offcanvas-area').style.opacity = '1';
            document.querySelector('.offcanvas-area').style.visibility = 'visible';
        });
        close_offcanvas.addEventListener('click', function () {
            document.querySelector('.offcanvas-area').style.opacity = '0';
            document.querySelector('.offcanvas-area').style.visibility = 'hidden';
        });
    }

    // Smooth scroll to top link
    $("a[href='#top']").on('click', function () {
        $("html, body").animate({ scrollTop: 0 }, "slow");
        return false;
    });

    // Toggle Switcher
    const toggle_switcher = function () {
        let $scope = $('.wcf__toggle_switcher');
        const checked = $("input", $scope);
        const toggle_pane = $(".toggle-pane", $scope);
        const toggle_label = $(".before_label, .after_label", $scope);
        checked.change(function () {
            toggle_pane.toggleClass('show');
            toggle_label.toggleClass('active');
        });
    };
    toggle_switcher();

})(jQuery);


// =====================================================
// OFFCANVAS 3 (offcanvas.js)
// =====================================================
let bodytag = document.querySelector('body');
let closeBtn = document.querySelector('.close-offcanvas');
let offcanvasBtn = document.querySelector('.open-offcanvas');
if (offcanvasBtn) {
    offcanvasBtn.addEventListener('click', () => {
        bodytag.style.overflow = "hidden";
    });
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            bodytag.style.overflow = "auto";
        });
    }
}

function showCanvas3() {
    var canvas3 = gsap.timeline();
    canvas3.to(".offcanvas-3__area", {
        left: 0, visibility: "visible", duration: 0.8, opacity: 1, rotationY: 0, perspective: 0,
    });
    canvas3.to(".offcanvas-3__menu ul li", {
        opacity: 1, top: 0, stagger: 0.05, duration: 1, rotationX: 0,
    }, "-=0.1");
    canvas3.to(".offcanvas-3__meta", {
        top: 0, visibility: "visible", duration: 0.8, opacity: 1,
    }, "-=0.5");
    canvas3.to(".offcanvas-3__social", {
        top: 0, visibility: "visible", duration: 0.8, opacity: 1,
    }, "-=0.5");
}

function hideCanvas3() {
    var canvas3 = gsap.timeline();
    canvas3.to(".offcanvas-3__area", { duration: 0.8, rotationY: -90, opacity: 0 });
    canvas3.to(".offcanvas-3__area", { visibility: "hidden", duration: 0.1, rotationY: 50, left: 0, rotationX: 0 });
    canvas3.to(".offcanvas-3__menu ul li", { opacity: 0, top: -100, stagger: 0.01, duration: 0.1, rotationX: 50 });
    canvas3.to(".offcanvas-3__meta", { top: -30, visibility: "hidden", duration: 0.8, opacity: 1 }, "-=0.5");
    canvas3.to(".offcanvas-3__social", { top: -30, visibility: "hidden", duration: 0.8, opacity: 1 }, "-=0.5");
}


// =====================================================
// BACK TO TOP (backToTop.js)
// =====================================================
!function (s) {
    "use strict";
    s(document).ready(function () {
        var e = document.querySelector(".progress-wrap path"),
            t = e.getTotalLength();
        e.style.transition = e.style.WebkitTransition = "none";
        e.style.strokeDasharray = t + " " + t;
        e.style.strokeDashoffset = t;
        e.getBoundingClientRect();
        e.style.transition = e.style.WebkitTransition = "stroke-dashoffset 10ms linear";
        var o = function () {
            var o = s(window).scrollTop(),
                r = s(document).height() - s(window).height(),
                i = t - o * t / r;
            e.style.strokeDashoffset = i;
        };
        o();
        s(window).scroll(o);
        jQuery(window).on("scroll", function () {
            jQuery(this).scrollTop() > 50
                ? jQuery(".progress-wrap").addClass("active-progress")
                : jQuery(".progress-wrap").removeClass("active-progress");
        });
        jQuery(".progress-wrap").on("click", function (s) {
            return s.preventDefault(), jQuery("html, body").animate({ scrollTop: 0 }, 550), !1;
        });
    });
}(jQuery);
