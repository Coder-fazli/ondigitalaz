<?php
/**
 * OnDigital Theme Functions
 *
 * @package OnDigital
 * @version 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ONDIGITAL_VERSION', '1.0.0' );
define( 'ONDIGITAL_DIR', get_template_directory() );
define( 'ONDIGITAL_URI', get_template_directory_uri() );

// =============================================================================
// 1. THEME SETUP
// =============================================================================

add_action( 'after_setup_theme', 'ondigital_setup' );
function ondigital_setup() {
    // Translation support
    load_theme_textdomain( 'ondigital', ONDIGITAL_DIR . '/languages' );

    // HTML5 support
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
    ) );

    // Title tag
    add_theme_support( 'title-tag' );

    // Post thumbnails
    add_theme_support( 'post-thumbnails' );

    // Custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 60,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ) );

    // Navigation menus
    register_nav_menus( array(
        'primary'   => __( 'Primary Menu', 'ondigital' ),
        'footer'    => __( 'Footer Menu', 'ondigital' ),
        'services'  => __( 'Services Menu', 'ondigital' ),
    ) );

    // Image sizes
    add_image_size( 'ondigital-hero', 1920, 1080, true );
    add_image_size( 'ondigital-blog-card', 600, 400, true );
    add_image_size( 'ondigital-project-card', 800, 600, true );
    add_image_size( 'ondigital-service-icon', 120, 120, true );
}


// =============================================================================
// 2. ENQUEUE STYLES & SCRIPTS
// =============================================================================

add_action( 'wp_enqueue_scripts', 'ondigital_enqueue_assets' );
function ondigital_enqueue_assets() {

    // --- Global Vendor CSS ---
    wp_enqueue_style( 'bootstrap', ONDIGITAL_URI . '/assets/css/vendor/bootstrap.min.css', array(), '5.3.0' );
    wp_enqueue_style( 'fontawesome', ONDIGITAL_URI . '/assets/css/vendor/all.min.css', array(), '6.5.0' );
    wp_enqueue_style( 'swiper', ONDIGITAL_URI . '/assets/css/vendor/swiper-bundle.min.css', array(), '11.0.0' );
    wp_enqueue_style( 'progressbar', ONDIGITAL_URI . '/assets/css/vendor/progressbar.css', array(), '1.0.0' );
    wp_enqueue_style( 'meanmenu', ONDIGITAL_URI . '/assets/css/vendor/meanmenu.min.css', array(), '2.0.8' );
    wp_enqueue_style( 'magnific-popup', ONDIGITAL_URI . '/assets/css/vendor/magnific-popup.css', array(), '1.1.0' );

    // --- Global Theme CSS ---
    wp_enqueue_style( 'ondigital-global', ONDIGITAL_URI . '/assets/css/global.css', array( 'bootstrap' ), ONDIGITAL_VERSION );

    // --- Per-Page CSS ---
    ondigital_enqueue_page_assets();

    // --- Global Vendor JS ---
    wp_enqueue_script( 'jquery' ); // WP bundled jQuery
    wp_enqueue_script( 'bootstrap-bundle', ONDIGITAL_URI . '/assets/js/vendor/bootstrap.bundle.min.js', array( 'jquery' ), '5.3.0', true );
    wp_enqueue_script( 'gsap', ONDIGITAL_URI . '/assets/js/vendor/gsap.min.js', array(), '3.12.0', true );
    wp_enqueue_script( 'gsap-scroll-trigger', ONDIGITAL_URI . '/assets/js/vendor/ScrollTrigger.min.js', array( 'gsap' ), '3.12.0', true );
    wp_enqueue_script( 'gsap-scroll-smoother', ONDIGITAL_URI . '/assets/js/vendor/ScrollSmoother.min.js', array( 'gsap' ), '3.12.0', true );
    wp_enqueue_script( 'gsap-scroll-to', ONDIGITAL_URI . '/assets/js/vendor/ScrollToPlugin.min.js', array( 'gsap' ), '3.12.0', true );
    wp_enqueue_script( 'gsap-split-text', ONDIGITAL_URI . '/assets/js/vendor/SplitText.min.js', array( 'gsap' ), '3.12.0', true );
    wp_enqueue_script( 'swiper', ONDIGITAL_URI . '/assets/js/vendor/swiper-bundle.min.js', array(), '11.0.0', true );
    wp_enqueue_script( 'magnific-popup', ONDIGITAL_URI . '/assets/js/vendor/jquery.magnific-popup.min.js', array( 'jquery' ), '1.1.0', true );
    wp_enqueue_script( 'meanmenu', ONDIGITAL_URI . '/assets/js/vendor/jquery.meanmenu.min.js', array( 'jquery' ), '2.0.8', true );
    wp_enqueue_script( 'counter-up', ONDIGITAL_URI . '/assets/js/vendor/counter.js', array(), '2.1.0', true );
    wp_enqueue_script( 'progressbar-js', ONDIGITAL_URI . '/assets/js/vendor/progressbar.js', array( 'jquery' ), '1.0.0', true );

    // --- Global Theme JS ---
    wp_enqueue_script( 'ondigital-global', ONDIGITAL_URI . '/assets/js/global.js', array( 'jquery', 'gsap', 'bootstrap-bundle' ), ONDIGITAL_VERSION, true );

    // Localize for AJAX
    wp_localize_script( 'ondigital-global', 'ondigital_ajax', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'nonce'    => wp_create_nonce( 'ondigital_nonce' ),
        'site_url' => home_url( '/' ),
    ) );
}

/**
 * Conditionally enqueue per-page CSS/JS based on the current template.
 */
function ondigital_enqueue_page_assets() {
    $page_styles = array(
        'page-home.php'            => 'home',
        'page-about.php'           => 'about',
        'page-services.php'        => 'services',
        'page-service-details.php' => 'service-details',
        'page-projects.php'        => 'projects',
        'page-blog.php'            => 'blog',
        'page-contact.php'         => 'contact',
        'page-quote.php'           => 'quote',
        'page-faq.php'             => 'faq',
        'page-team.php'            => 'team',
    );

    foreach ( $page_styles as $template => $slug ) {
        if ( is_page_template( 'templates/' . $template ) ) {
            $css_file = ONDIGITAL_DIR . '/assets/css/pages/' . $slug . '.css';
            if ( file_exists( $css_file ) ) {
                wp_enqueue_style( 'ondigital-' . $slug, ONDIGITAL_URI . '/assets/css/pages/' . $slug . '.css', array( 'ondigital-global' ), ONDIGITAL_VERSION );
            }

            $js_file = ONDIGITAL_DIR . '/assets/js/pages/' . $slug . '.js';
            if ( file_exists( $js_file ) ) {
                wp_enqueue_script( 'ondigital-' . $slug, ONDIGITAL_URI . '/assets/js/pages/' . $slug . '.js', array( 'ondigital-global' ), ONDIGITAL_VERSION, true );
            }
            break;
        }
    }

    // Blog single post
    if ( is_singular( 'post' ) ) {
        $css_file = ONDIGITAL_DIR . '/assets/css/pages/blog-details.css';
        if ( file_exists( $css_file ) ) {
            wp_enqueue_style( 'ondigital-blog-details', ONDIGITAL_URI . '/assets/css/pages/blog-details.css', array( 'ondigital-global' ), ONDIGITAL_VERSION );
        }
        $js_file = ONDIGITAL_DIR . '/assets/js/pages/blog-details.js';
        if ( file_exists( $js_file ) ) {
            wp_enqueue_script( 'ondigital-blog-details', ONDIGITAL_URI . '/assets/js/pages/blog-details.js', array( 'ondigital-global' ), ONDIGITAL_VERSION, true );
        }
    }

    // Single Service
    if ( is_singular( 'service' ) ) {
        $css_file = ONDIGITAL_DIR . '/assets/css/pages/service-details.css';
        if ( file_exists( $css_file ) ) {
            wp_enqueue_style( 'ondigital-service-details', ONDIGITAL_URI . '/assets/css/pages/service-details.css', array( 'ondigital-global' ), ONDIGITAL_VERSION );
        }
    }

    // Single Project
    if ( is_singular( 'project' ) ) {
        $css_file = ONDIGITAL_DIR . '/assets/css/pages/project-details.css';
        if ( file_exists( $css_file ) ) {
            wp_enqueue_style( 'ondigital-project-details', ONDIGITAL_URI . '/assets/css/pages/project-details.css', array( 'ondigital-global' ), ONDIGITAL_VERSION );
        }
    }

    // 404
    if ( is_404() ) {
        $css_file = ONDIGITAL_DIR . '/assets/css/pages/404.css';
        if ( file_exists( $css_file ) ) {
            wp_enqueue_style( 'ondigital-404', ONDIGITAL_URI . '/assets/css/pages/404.css', array( 'ondigital-global' ), ONDIGITAL_VERSION );
        }
    }
}


// =============================================================================
// 3. WIDGETS
// =============================================================================

add_action( 'widgets_init', 'ondigital_widgets_init' );
function ondigital_widgets_init() {
    register_sidebar( array(
        'name'          => __( 'Blog Sidebar', 'ondigital' ),
        'id'            => 'blog-sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 1', 'ondigital' ),
        'id'            => 'footer-1',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 2', 'ondigital' ),
        'id'            => 'footer-2',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ) );

    register_sidebar( array(
        'name'          => __( 'Footer Column 3', 'ondigital' ),
        'id'            => 'footer-3',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-widget-title">',
        'after_title'   => '</h4>',
    ) );
}


// =============================================================================
// 4. AUTO-UPDATES (ENABLED)
// =============================================================================

// Enable auto-updates for core
add_filter( 'allow_major_auto_core_updates', '__return_true' );
add_filter( 'allow_minor_auto_core_updates', '__return_true' );

// Enable auto-updates for plugins
add_filter( 'auto_update_plugin', '__return_true' );

// Enable auto-updates for themes
add_filter( 'auto_update_theme', '__return_true' );

// Enable auto-updates for translations
add_filter( 'auto_update_translation', '__return_true' );


// =============================================================================
// 5. SECURITY HARDENING
// =============================================================================

// Remove WordPress version from head and feeds
remove_action( 'wp_head', 'wp_generator' );
add_filter( 'the_generator', '__return_empty_string' );

// Remove version from enqueued styles and scripts
add_filter( 'style_loader_src', 'ondigital_remove_wp_version_strings', 9999 );
add_filter( 'script_loader_src', 'ondigital_remove_wp_version_strings', 9999 );
function ondigital_remove_wp_version_strings( $src ) {
    if ( strpos( $src, 'ver=' . get_bloginfo( 'version' ) ) ) {
        $src = remove_query_arg( 'ver', $src );
    }
    return $src;
}

// Disable XML-RPC
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'wp_headers', 'ondigital_remove_x_pingback' );
function ondigital_remove_x_pingback( $headers ) {
    unset( $headers['X-Pingback'] );
    return $headers;
}

// Disable file editing in admin dashboard
if ( ! defined( 'DISALLOW_FILE_EDIT' ) ) {
    define( 'DISALLOW_FILE_EDIT', true );
}

// Remove unnecessary head links
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'wp_shortlink_wp_head' );
remove_action( 'wp_head', 'rest_output_link_wp_head' );
remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
remove_action( 'wp_head', 'wp_oembed_add_host_js' );

// Disable REST API user enumeration for non-authenticated users
add_filter( 'rest_endpoints', 'ondigital_disable_user_enumeration_rest' );
function ondigital_disable_user_enumeration_rest( $endpoints ) {
    if ( ! is_user_logged_in() ) {
        if ( isset( $endpoints['/wp/v2/users'] ) ) {
            unset( $endpoints['/wp/v2/users'] );
        }
        if ( isset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] ) ) {
            unset( $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
        }
    }
    return $endpoints;
}

// Block author archive enumeration
add_action( 'template_redirect', 'ondigital_block_author_enum' );
function ondigital_block_author_enum() {
    if ( is_author() && ! is_user_logged_in() ) {
        wp_safe_redirect( home_url(), 301 );
        exit;
    }
}

// Add security headers
add_action( 'send_headers', 'ondigital_security_headers' );
function ondigital_security_headers() {
    if ( ! is_admin() ) {
        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'X-XSS-Protection: 1; mode=block' );
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );
        header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
    }
}

// Limit login attempts (basic)
add_filter( 'authenticate', 'ondigital_limit_login_attempts', 30, 3 );
function ondigital_limit_login_attempts( $user, $username, $password ) {
    if ( empty( $username ) ) {
        return $user;
    }

    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    $transient_key = 'login_attempts_' . md5( $ip );
    $attempts = (int) get_transient( $transient_key );

    if ( $attempts >= 5 ) {
        return new WP_Error(
            'too_many_attempts',
            __( 'Too many login attempts. Please try again in 15 minutes.', 'ondigital' )
        );
    }

    // Increment on failed attempts
    if ( is_wp_error( $user ) ) {
        set_transient( $transient_key, $attempts + 1, 15 * MINUTE_IN_SECONDS );
    }

    return $user;
}

// Disable application passwords for non-admin users
add_filter( 'wp_is_application_passwords_available_for_user', 'ondigital_restrict_app_passwords', 10, 2 );
function ondigital_restrict_app_passwords( $available, $user ) {
    if ( ! user_can( $user, 'manage_options' ) ) {
        return false;
    }
    return $available;
}


// =============================================================================
// 6. CUSTOM POST TYPES
// =============================================================================

add_action( 'init', 'ondigital_register_post_types' );
function ondigital_register_post_types() {
    // Projects CPT
    register_post_type( 'project', array(
        'labels' => array(
            'name'               => __( 'Projects', 'ondigital' ),
            'singular_name'      => __( 'Project', 'ondigital' ),
            'add_new_item'       => __( 'Add New Project', 'ondigital' ),
            'edit_item'          => __( 'Edit Project', 'ondigital' ),
            'view_item'          => __( 'View Project', 'ondigital' ),
            'all_items'          => __( 'All Projects', 'ondigital' ),
            'search_items'       => __( 'Search Projects', 'ondigital' ),
            'not_found'          => __( 'No projects found.', 'ondigital' ),
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array( 'slug' => 'layiheler' ),
        'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt' ),
        'menu_icon'    => 'dashicons-portfolio',
        'show_in_rest' => true,
    ) );

    // Services CPT
    register_post_type( 'service', array(
        'labels' => array(
            'name'               => __( 'Services', 'ondigital' ),
            'singular_name'      => __( 'Service', 'ondigital' ),
            'add_new_item'       => __( 'Add New Service', 'ondigital' ),
            'edit_item'          => __( 'Edit Service', 'ondigital' ),
            'view_item'          => __( 'View Service', 'ondigital' ),
            'all_items'          => __( 'All Services', 'ondigital' ),
            'search_items'       => __( 'Search Services', 'ondigital' ),
            'not_found'          => __( 'No services found.', 'ondigital' ),
        ),
        'public'       => true,
        'has_archive'  => true,
        'rewrite'      => array( 'slug' => 'xidmetler' ),
        'supports'     => array( 'title', 'editor', 'thumbnail', 'excerpt', 'page-attributes' ),
        'menu_icon'    => 'dashicons-admin-tools',
        'show_in_rest' => true,
    ) );

    // Team CPT
    register_post_type( 'team_member', array(
        'labels' => array(
            'name'               => __( 'Team', 'ondigital' ),
            'singular_name'      => __( 'Team Member', 'ondigital' ),
            'add_new_item'       => __( 'Add New Team Member', 'ondigital' ),
            'edit_item'          => __( 'Edit Team Member', 'ondigital' ),
            'view_item'          => __( 'View Team Member', 'ondigital' ),
            'all_items'          => __( 'All Team Members', 'ondigital' ),
        ),
        'public'       => true,
        'has_archive'  => false,
        'rewrite'      => array( 'slug' => 'komanda' ),
        'supports'     => array( 'title', 'editor', 'thumbnail' ),
        'menu_icon'    => 'dashicons-groups',
        'show_in_rest' => true,
    ) );
}

// Project Categories Taxonomy
add_action( 'init', 'ondigital_register_taxonomies' );
function ondigital_register_taxonomies() {
    register_taxonomy( 'project_category', 'project', array(
        'labels' => array(
            'name'          => __( 'Project Categories', 'ondigital' ),
            'singular_name' => __( 'Project Category', 'ondigital' ),
        ),
        'public'       => true,
        'hierarchical' => true,
        'rewrite'      => array( 'slug' => 'layihe-kateqoriya' ),
        'show_in_rest' => true,
    ) );
}


// =============================================================================
// 7. THEME CUSTOMIZER
// =============================================================================

add_action( 'customize_register', 'ondigital_customizer' );
function ondigital_customizer( $wp_customize ) {

    // --- Contact Info Section ---
    $wp_customize->add_section( 'ondigital_contact', array(
        'title'    => __( 'Contact Information', 'ondigital' ),
        'priority' => 30,
    ) );

    $contact_fields = array(
        'phone'     => array( 'label' => __( 'Phone Number', 'ondigital' ), 'default' => '+994 (55) 431 47 50' ),
        'email'     => array( 'label' => __( 'Email Address', 'ondigital' ), 'default' => 'office@ondigital.az' ),
        'address'   => array( 'label' => __( 'Address', 'ondigital' ), 'default' => 'Old Town Plaza, Baku' ),
    );

    foreach ( $contact_fields as $key => $field ) {
        $wp_customize->add_setting( 'ondigital_' . $key, array(
            'default'           => $field['default'],
            'sanitize_callback' => 'sanitize_text_field',
        ) );
        $wp_customize->add_control( 'ondigital_' . $key, array(
            'label'   => $field['label'],
            'section' => 'ondigital_contact',
            'type'    => 'text',
        ) );
    }

    // --- Social Media Section ---
    $wp_customize->add_section( 'ondigital_social', array(
        'title'    => __( 'Social Media Links', 'ondigital' ),
        'priority' => 35,
    ) );

    $socials = array( 'facebook', 'instagram', 'linkedin', 'tiktok', 'youtube', 'behance', 'pinterest' );
    foreach ( $socials as $social ) {
        $wp_customize->add_setting( 'ondigital_' . $social, array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
        ) );
        $wp_customize->add_control( 'ondigital_' . $social, array(
            'label'   => ucfirst( $social ) . ' URL',
            'section' => 'ondigital_social',
            'type'    => 'url',
        ) );
    }
}


// =============================================================================
// 8. HELPER FUNCTIONS
// =============================================================================

/**
 * Get theme mod with fallback.
 */
function ondigital_get_option( $key, $default = '' ) {
    return get_theme_mod( 'ondigital_' . $key, $default );
}

/**
 * Get social media links as array.
 */
function ondigital_get_social_links() {
    $socials = array( 'facebook', 'instagram', 'linkedin', 'tiktok', 'youtube', 'behance', 'pinterest' );
    $links = array();
    foreach ( $socials as $social ) {
        $url = ondigital_get_option( $social );
        if ( ! empty( $url ) ) {
            $links[ $social ] = $url;
        }
    }
    return $links;
}

/**
 * Sanitize SVG output.
 */
function ondigital_kses_svg( $svg ) {
    $allowed = array(
        'svg'  => array( 'class' => true, 'xmlns' => true, 'viewbox' => true, 'width' => true, 'height' => true, 'fill' => true ),
        'path' => array( 'd' => true, 'fill' => true, 'stroke' => true, 'stroke-width' => true ),
        'g'    => array( 'fill' => true, 'transform' => true ),
    );
    return wp_kses( $svg, $allowed );
}


// =============================================================================
// 9. EXCERPT CUSTOMIZATION
// =============================================================================

add_filter( 'excerpt_length', function() { return 25; } );
add_filter( 'excerpt_more', function() { return '...'; } );


// =============================================================================
// 10. DISABLE COMMENTS SITE-WIDE (optional — remove if you need comments)
// =============================================================================

add_action( 'admin_init', function() {
    // Redirect comments page
    global $pagenow;
    if ( $pagenow === 'edit-comments.php' ) {
        wp_safe_redirect( admin_url() );
        exit;
    }
    // Remove comments metabox from dashboard
    remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
    // Disable support for comments on post types
    foreach ( get_post_types() as $post_type ) {
        if ( post_type_supports( $post_type, 'comments' ) ) {
            remove_post_type_support( $post_type, 'comments' );
            remove_post_type_support( $post_type, 'trackbacks' );
        }
    }
} );

add_filter( 'comments_open', '__return_false', 20, 2 );
add_filter( 'pings_open', '__return_false', 20, 2 );
add_filter( 'comments_array', '__return_empty_array', 10, 2 );

add_action( 'admin_menu', function() {
    remove_menu_page( 'edit-comments.php' );
} );

add_action( 'wp_before_admin_bar_render', function() {
    global $wp_admin_bar;
    $wp_admin_bar->remove_menu( 'comments' );
} );
